<?php

$x = 5;
$y = 6;
$a = 34;
$b = 37;
$p = 23;
$q = 45;

echo $x + $y;
echo "<br>";
echo $a + $b;
echo "<br>";
echo $p + $q;
echo "<br>";
?>