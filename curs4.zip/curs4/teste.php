<h1>
    Continut incarcat din teste.php
</h1>

<?php
$x=1000;
?>