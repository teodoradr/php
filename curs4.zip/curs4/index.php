<?php
//$a = false;
//if(!$a==($b=!false))
//{
//    echo "Salut";
//}

// $x = false;
// $a = ((2+3)==5 && (true == -25) || $x == true);
// echo $a;

// var_dump(true == -25);

// $i = 25;
// if($i==1) echo "Hello";
// else if($i=2) echo "Hello World";
// else if($i==25) echo "Hello World and Goodbye";
// else "Error";

// $x = 10;
// if($x==25); echo "x este 25";

// for($i=0;$i<10;$i++){
//     if($i>5) continue;
//     echo $i;
// }

// $x = 7
// while ($x < 30){
//     $x .= 2;
// }
// echo $x;



?>
