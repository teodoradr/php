<?php

echo "pas1";
echo "<br>";
require "teste2.php";
echo "<br>";
echo "pas2";
echo "<br>";
include_once "teste2.php";
echo $x;

?>