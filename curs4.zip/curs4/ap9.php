<?php
//declare(strict_types = 1);
function suma(int $x, int $y):int{
    echo $x+$y;
    return 0;
}
suma(5,8);
//Suma('aaa',10)
?>